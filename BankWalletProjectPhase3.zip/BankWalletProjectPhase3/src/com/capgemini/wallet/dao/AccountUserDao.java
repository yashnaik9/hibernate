package com.capgemini.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.bean.Transaction;
import com.capgemini.wallet.exception.WalletException;

public class AccountUserDao implements IAccountUserDao {

	private Map<Integer, AccountUser> Accuser = new HashMap<>();

	private Map<Integer, Double> Wallet = new HashMap<>();

	Transaction[] txns;
	int idxx;

	// @Override
	// public void createUser(String name, String age, String address, String
	// email)
	// throws WalletException {
	//
	// // au.setName(name);
	// // au.setAge(Integer.parseInt(age));
	// // au.setAddress(address);
	// // au.setEmail(email);
	// // double amount = 0;
	// txns = new Transaction[10];
	//
	// // txns[idxx++] = new Transaction("CR", au.getBalance(), amount);
	//
	// }

	@Override
	public void createUser(String name, String age, String address, String email) {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		AccountUser au = new AccountUser();
		au.setName(name);
		au.setAge(Integer.parseInt(age));
		au.setAddress(address);
		au.setEmail(email);
		au.setBalance(0);
		em.persist(au); // persist is equivalent to insert into
		System.out.println(au.getCode());
		em.getTransaction().commit();
		System.out.println("Added one user to database.");

		em.close();
		factory.close();
	}

	@Override
	public Map<Integer, AccountUser> displayAccountUser() {

		return null;
	}

	@Override
	public void storeIntoWalletMap() {

		// Wallet.put(au.getCode(), au.getBalance());

	}

	@Override
	public Map<Integer, AccountUser> displayWalletDetails() {

		return null;
	}

	@Override
	public double showBalance(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		AccountUser au = em.find(AccountUser.class, Accno);
		em.close();
		factory.close();
		return au.getBalance();

	}

	@Override
	public void depositMoney(double amount, int accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, accno);
			if (au != null) {
				double bal = au.getBalance();
				au.setBalance(bal + amount);
				em.merge(au);
				em.getTransaction().commit();
				insertIntoTransaction(accno, "CR", amount, bal);
			} else {
				throw new WalletException("No such account Found ");
			}
		} finally {
			em.close();
			factory.close();
		}
	}

	@Override
	public void withdrawMoney(double amount, int Accno) throws WalletException {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, Accno);
			if (au != null) {
				double bal = au.getBalance();
				if (bal > amount) {
					au.setBalance(bal - amount);
					em.merge(au);
					em.getTransaction().commit();
					insertIntoTransaction(Accno, "DR", amount, bal);
				} else {
					throw new WalletException("Insufficient funds");
				}
			} else {
				throw new WalletException("No such account Found ");
			}

		} finally {
			em.close();
			factory.close();
		}
	}

	@Override
	public void fundTransfer(double amount, int accno, int Accno)
			throws WalletException {

		withdrawMoney(amount, Accno);
		depositMoney(amount, accno);

	}

	@Override
	public boolean validateAccountNo(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();

		try {

			AccountUser au = em.find(AccountUser.class, Accno);
			if (au != null) {
				return true;
			} else {
				throw new WalletException("User Does not exist");
			}
		} finally {
			em.close();
			factory.close();
		}

	}

	@Override
	public void insertIntoTransaction(int Accno, String type, double amount,
			double balance) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Transaction trans = new Transaction(Accno, type, amount, balance);
		em.persist(trans);
		em.getTransaction().commit();
		em.close();
		factory.close();

	}

	@Override
	public void printTransaction(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		ArrayList<Transaction> list = (ArrayList<Transaction>) em
				.createQuery(
						"Select trans from Transaction trans where Accno = :Accno order by trans,id",
						Transaction.class).setParameter("Accno", Accno)
				.getResultList();
		for (Transaction transaction : list) {
			System.out.println(transaction.printDetails());
		}

	}

	@Override
	public void storeIntoMap() {
		// TODO Auto-generated method stub

	}

}
