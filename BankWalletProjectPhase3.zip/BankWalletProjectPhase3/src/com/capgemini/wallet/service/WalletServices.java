package com.capgemini.wallet.service;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.dao.AccountUserDao;
import com.capgemini.wallet.exception.WalletException;



public class WalletServices implements IWalletServices {

	AccountUserDao aud = new AccountUserDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAge(String userAge) {

		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserEmailAddress(String userAddress) {
		if (userAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	
	@Override
	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
		return false;
	}
	@Override
	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
		return false;
	}

	@Override
	public void storeIntoMap() {
		aud.storeIntoMap();
		
	}

	@Override
	public Map<Integer, AccountUser> displayCustomer() {
		
		return null;
	}

	@Override
	public void createUser(String name, String age, String address, String email) throws WalletException {

		aud.createUser(name, age, address, email);
		
		
	}
	@Override
	public double showBalance(int accno) throws WalletException{
		return aud.showBalance(accno);

	}

	@Override
	public void depositMoney(double amount,int Accno) throws WalletException {
		aud.depositMoney(amount,Accno);

	}

	@Override
	public void withdrawMoney(double amount, int accno) throws WalletException {
		aud.withdrawMoney(amount,accno);

	}

	@Override
	public void fundTransfer(double amount,int accno,int Accno) throws WalletException {
      aud.fundTransfer(amount,accno,Accno);
	}

	@Override
	public void printTransaction(int Accno) throws WalletException {
	aud.printTransaction(Accno);
		
	}

	@Override
	public boolean validateAccountNo(int Accno) throws WalletException {
		aud.validateAccountNo(Accno);
		return false;
	}
	

	

	

}
